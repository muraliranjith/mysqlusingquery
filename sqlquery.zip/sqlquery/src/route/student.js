const studentController = require('../controller/student.controller');

const router = require('express').Router()

router.post('/createtable',studentController.createTable)
router.get('/mysql',studentController.getStudents);
router.post('/mysql',studentController.createStudent);

router.get('/mysql/:id',studentController.getStudentById);
router.delete('/mysql/:id',studentController.deleteStudentById);
router.put('/mysql/:id',studentController.updateStudentById)

module.exports= router;