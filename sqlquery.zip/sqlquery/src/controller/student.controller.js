const db = require('../db.connection')
const studentService = require('../service/student')

const createTable = async (req, res) => {
    await studentService.createTable();

    res.send('table created');
}
const getStudents = async (req, res) => {
    const user = await studentService.getStudents();

    res.send(user);
}

const getStudentById = async (req, res) => {

    const user = await studentService.getStudentById(req.params.id);

    res.send(user);
}

const deleteStudentById = async (req, res) => {

    const user = await studentService.deleteById(req.params.id);

    res.send(user);
}

const createStudent = async (req, res) => {

    const payload = {
        name: req.body.name,
        age: req.body.age,
        department: req.body.department
    }
    const user = await studentService.createStudent(payload);

    res.send(user);
}

const updateStudentById = async (req, res) => {
    const payload = {
        name: req.body.name,
        age: req.body.age,
        department: req.body.department
    }
    const id = req.params.id;
    const user = await studentService.updateById(id, payload);

    res.send(user);
}
module.exports = {
    createTable,
    getStudents,
    getStudentById,
    deleteStudentById,
    createStudent,
    updateStudentById
}