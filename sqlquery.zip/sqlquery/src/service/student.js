const db = require('../db.connection')



const createTable = async () => {
    return new Promise((res,req)=>{
        db.query("CREATE TABLE students (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(255), age VARCHAR(255), department VARCHAR(255))", (err, result) => {
            if (err) {
                console.log("error", err);
            }
            return res (result);
        })
    })
}
const getStudents = async (sql) => {
    return new Promise((res,req)=>{
        db.query('select * from students', (err, result) => {
            if (err) {
                console.log("error", err);
            }
            return res (result);
        })
    })
}

const getStudentById = (id) => {
    return new Promise((res,req)=>{
        db.query(`select * from students where id=?`, [id], (err, result) => {
            if (err) {
                console.log("error", err);
            }
            return res (result);
        })
    })
};

const deleteById = async (id) => {
    return new Promise((res,req)=>{
        db.query('Delete from students where id=?',[id], (err, result) => {
            if (err) {
                console.log("error", err);
            }
            return res (result);
        })
    })
}
const createStudent = async (payload) => {
    return new Promise((res,req)=>{
        db.query("insert into students values(null,'" + payload.name + "','" + payload.age + "','" + payload.department + "')", (err, result) => {
            if (err) {
                console.log("error", err);
            }
            return res (result);
        })
    })
}

const updateById = async (id,payload) => {
    return new Promise((res,req)=>{
        db.query("update students set name='" + payload.name + "',age= " + payload.age + ",department='" + payload.department +"' where id=? ",[id], (err, result) => {
            if (err) {
                console.log("error", err);
            }
            return res (result);
        })
    })
}

module.exports = {
    createTable,
    getStudents,
    getStudentById,
    deleteById,
    createStudent,
    updateById

}